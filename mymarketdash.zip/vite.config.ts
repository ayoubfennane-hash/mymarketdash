import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
  plugins: [react()],
  server: { host: "0.0.0.0", port: 3000, strictPort: true, allowedHosts: true },
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          excel: ["xlsx"],
          charts: ["recharts"],
          categories: ["./src/category-source.json"],
        },
      },
    },
  },
});
